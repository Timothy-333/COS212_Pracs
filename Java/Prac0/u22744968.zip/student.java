public class student {
    public void sayHello()
    {
        System.out.println("I u22744968 am a COS212 student. I pinky promise that I will work hard in this module and not cheat!!!");
    }
}
